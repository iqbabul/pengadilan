<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Content Row -->
    <div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-content">
                <div class="card-body">
                    <p class="card-text">
                    Peringatan
                    </p>
                    <hr>
                    <p class="card-text">
                        Anda harus mengisi form penilaian terlebih dahulu klik <a href="<?=base_url('admin/penilaian')?>">di sini</a>
                    </p>
                </div>
            </div>
        </div>
    </div>

    </div>
</div>
<!-- /.container-fluid -->